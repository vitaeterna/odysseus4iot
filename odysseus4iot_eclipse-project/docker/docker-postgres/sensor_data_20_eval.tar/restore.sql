--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.8
-- Dumped by pg_dump version 12.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "CattleDB";
--
-- Name: CattleDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "CattleDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'German_Germany.1252' LC_CTYPE = 'German_Germany.1252';


ALTER DATABASE "CattleDB" OWNER TO postgres;

\connect "CattleDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sensor_data_20_eval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sensor_data_20_eval (
    cattle_id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    ax double precision NOT NULL,
    ay double precision NOT NULL,
    az double precision NOT NULL,
    ox double precision NOT NULL,
    oy double precision NOT NULL,
    oz double precision NOT NULL
);


ALTER TABLE public.sensor_data_20_eval OWNER TO postgres;

--
-- Data for Name: sensor_data_20_eval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sensor_data_20_eval (cattle_id, "timestamp", ax, ay, az, ox, oy, oz) FROM stdin;
\.
COPY public.sensor_data_20_eval (cattle_id, "timestamp", ax, ay, az, ox, oy, oz) FROM '$$PATH$$/2873.dat';

--
-- PostgreSQL database dump complete
--

